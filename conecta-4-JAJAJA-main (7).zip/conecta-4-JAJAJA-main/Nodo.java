
public class Nodo {
	int dato;
	Nodo Arriba, Abajo, Derecha, Izquierda;
	
	public Nodo()
	{
		 	dato=0;
		 	Izquierda= null;
			Derecha= null;
			Arriba= null;
			Abajo= null;
	} 
}
